package com.example.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.repository.CategoryRepository;
import com.example.exception.ResourceNotFoundException;
import com.example.model.Category;
import com.example.service.CategoryService;

@Service

public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryRepository categorRepository;
		
		
		
		public CategoryServiceImpl(CategoryRepository categoryRepository) {
			super();
			this.categorRepository = categoryRepository;
		}
	
	@Override
	public Category saveCategory(Category category) {
		// TODO Auto-generated method stub
		return categorRepository.save(category);
	}

	@Override
	public Category getCategoryByCategoryCode(long categoryCode) {
		// TODO Auto-generated method stub
		Category category= categorRepository.findById(categoryCode).orElseThrow(()->new ResourceNotFoundException("Category","categoryCode",categoryCode));
		long nextNumber =category.getNextNumber();
		long sum=0;
		while(nextNumber>0)
		{
			System.out.println("in loop");
			long rem=nextNumber%10;
			sum=sum+rem;
			nextNumber/=10;
		}
		System.out.println("out of loop"+sum);
		sum+=10;
		category.setNextNumber(sum);
		categorRepository.save(category);
		return categorRepository.findById(categoryCode).orElseThrow(()->new ResourceNotFoundException("Category","categoryCode",categoryCode));
	}

}
