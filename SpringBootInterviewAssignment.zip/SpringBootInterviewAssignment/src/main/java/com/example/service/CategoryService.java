package com.example.service;

import com.example.model.Category;

public interface CategoryService {
	Category saveCategory(Category category);

	Category getCategoryByCategoryCode(long categoryCode);
}
