package com.example.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="category_table")
public class Category {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="category_code")
	private long CategoryCode;
	
	@Column(name="next_number")
	//@NotEmpty
	//@Size(min=3 , message="firstName must contain atleast 3 characters")
	private long nextNumber;
	
	

	public long getCategoryCode() {
		return CategoryCode;
	}

	public void setCategoryCode(long categoryCode) {
		CategoryCode = categoryCode;
	}

	public long getNextNumber() {
		return nextNumber;
	}

	public void setNextNumber(long nextNumber) {
		this.nextNumber = nextNumber;
	}

	
	
	
}
