package com.example.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.model.Category;
import com.example.service.CategoryService;

@RestController
@RequestMapping("/FetchNextNumber")
public class CategoryController {

	@Autowired
	private CategoryService categoryService;
	
	@PostMapping("/register")
	public ResponseEntity<Category> saveCategory(@RequestBody Category category) {

		return new ResponseEntity<Category>(categoryService.saveCategory(category), HttpStatus.CREATED);
	}
	@GetMapping("{categoryCode}")
	public ResponseEntity<Category> getCategoryByCategoryCode(@PathVariable("categoryCode") long categoryCode) {
		return new ResponseEntity<Category>(categoryService.getCategoryByCategoryCode(categoryCode), HttpStatus.OK);
	}
	
}
