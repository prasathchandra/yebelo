package com.example;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.model.Category;
import com.example.repository.CategoryRepository;


@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class CategoryTestCase {

@Autowired
CategoryRepository categoryRepository;




//adding category
@Test
@Order(1)
public void testCreate()
{

Category category=new Category();
//category.setFirstName("java");
assertNotNull(categoryRepository.save(category));
//assertNotNull(CategoryRepository.findById(2L).get());
}






}